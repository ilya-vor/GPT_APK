# output-json
from index_main import User

# ignore-above
from pydantic import ValidationError

try:
    User(signup_ts='broken', friends=[1, 2, 'not number'])
except ValidationError as e:
    print(e.json())
# requires: User from previous example
